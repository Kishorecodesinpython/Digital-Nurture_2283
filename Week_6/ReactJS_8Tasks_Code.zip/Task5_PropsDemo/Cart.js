import React from 'react';

class Cart extends React.Component {
  static defaultProps = {
    itemname: "Unknown Item",
    price: 0
  };

  render() {
    return (
      <div>
        <h3>Item: {this.props.itemname}</h3>
        <p>Price: ₹{this.props.price}</p>
      </div>
    );
  }
}

export default Cart;