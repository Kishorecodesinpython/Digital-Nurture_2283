import React from 'react';
import Cart from './Cart';

class OnlineShopping extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [
        { itemname: "Mobile", price: 12000 },
        { itemname: "Laptop", price: 45000 },
        { itemname: "Headphones", price: 1500 },
        { itemname: "Watch", price: 5000 },
        { itemname: "Camera", price: 25000 }
      ]
    };
  }

  render() {
    return (
      <div>
        <h2>Online Shopping</h2>
        {this.state.items.map((item, i) => (
          <Cart key={i} itemname={item.itemname} price={item.price} />
        ))}
      </div>
    );
  }
}

export default OnlineShopping;