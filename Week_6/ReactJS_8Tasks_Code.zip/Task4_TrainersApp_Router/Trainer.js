class Trainer {
  constructor(id, name, email, phone, technology, skills) {
    this.trainerId = id;
    this.name = name;
    this.email = email;
    this.phone = phone;
    this.technology = technology;
    this.skills = skills;
  }
}
export default Trainer;