const trainers = [
  { trainerId: 1, name: "Alice", email: "alice@mail.com", phone: "1111111111", technology: "React", skills: ["JS", "Hooks"] },
  { trainerId: 2, name: "Bob", email: "bob@mail.com", phone: "2222222222", technology: "Node", skills: ["Express", "MongoDB"] }
];
export default trainers;