import React from 'react';

class CountPeople extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      entrycount: 0,
      exitcount: 0
    };
  }

  UpdateEntry = () => {
    this.setState(prev => ({ entrycount: prev.entrycount + 1 }));
  }

  UpdateExit = () => {
    this.setState(prev => ({ exitcount: prev.exitcount + 1 }));
  }

  render() {
    return (
      <div style={{ padding: "20px", textAlign: "center" }}>
        <h2>Welcome to the Mall</h2>
        <p>People Entered: {this.state.entrycount}</p>
        <p>People Exited: {this.state.exitcount}</p>
        <button onClick={this.UpdateEntry}>Login</button>&nbsp;
        <button onClick={this.UpdateExit}>Exit</button>
      </div>
    );
  }
}

export default CountPeople;