import React, { useState } from 'react';

function ScoreCalculator() {
  const [marks, setMarks] = useState({ math: 0, science: 0, english: 0 });
  const [total, setTotal] = useState(0);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setMarks(prev => ({ ...prev, [name]: Number(value) }));
  };

  const calculateTotal = () => {
    setTotal(marks.math + marks.science + marks.english);
  };

  return (
    <div>
      <h2>Score Calculator</h2>
      <input name="math" onChange={handleChange} placeholder="Math Marks" />
      <input name="science" onChange={handleChange} placeholder="Science Marks" />
      <input name="english" onChange={handleChange} placeholder="English Marks" />
      <button onClick={calculateTotal}>Calculate Total</button>
      <h3>Total: {total}</h3>
    </div>
  );
}

export default ScoreCalculator;