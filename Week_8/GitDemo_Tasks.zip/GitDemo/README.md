
# Git Hands-On Lab - Conflict Resolution, Cleanup, and Branch Operations

This repository demonstrates step-by-step Git operations as part of a hands-on lab series. These tasks simulate real-world version control activities such as branch creation, file modification, merge conflict resolution, cleanup, and pushing changes to a remote repository.

## 🧪 Hands-on Lab Overview

### ✅ Git-T03-HOL_001: Conflict Resolution During Merge
- Create branch `GitWork` and commit `hello.xml`.
- Create conflicting file in `master`, attempt merge, resolve manually or using 3-way merge tool.
- Add `.gitignore` to avoid backup file commits.
- Clean up merged branches.

### ✅ Git-T03-HOL_002: Cleanup and Push to Remote
- Pull changes, push remaining commits to remote.

### ✅ Git-T03-HOL_003: Revert and Amend
- Demonstrate `git revert` and `git commit --amend` with `--force` push.

### ✅ Git-T03-HOL_004: Rebase Operations
- Create commits in separate branches, perform interactive rebase, resolve conflicts.

### ✅ Git-T03-HOL_005: Cherry-Pick Commit
- Cherry-pick selected commits onto another branch, resolve any conflicts.

---

## 🔧 Tools & Commands Used
- Git Bash / Terminal
- `git status`, `git branch`, `git merge`, `git rebase`, `git cherry-pick`, `git log`
- `.gitignore` for ignoring backup files

---

## 📁 Repository Structure
/GitDemo
├── hello.xml
├── welcome.txt
├── log.txt
├── revert_demo.txt
├── amend_demo.txt
├── rebase_feature.txt
├── master_update.txt
├── cherry_pick.txt
├── .gitignore
└── README.md

---

## 📅 Date Completed
August 2025
