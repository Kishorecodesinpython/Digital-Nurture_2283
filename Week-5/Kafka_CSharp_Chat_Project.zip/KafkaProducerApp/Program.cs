using System;
using System.Threading.Tasks;
using Confluent.Kafka;

namespace KafkaProducerApp
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var config = new ProducerConfig
            {
                BootstrapServers = "localhost:9092"
            };

            using var producer = new ProducerBuilder<Null, string>(config).Build();

            Console.WriteLine("Kafka Producer started. Type messages to send. Type 'exit' to quit.");

            while (true)
            {
                Console.Write("Enter message: ");
                string message = Console.ReadLine();

                if (message.ToLower() == "exit")
                    break;

                var result = await producer.ProduceAsync("chat-topic", new Message<Null, string>
                {
                    Value = message
                });

                Console.WriteLine($"Message sent to {result.TopicPartitionOffset}");
            }
        }
    }
}